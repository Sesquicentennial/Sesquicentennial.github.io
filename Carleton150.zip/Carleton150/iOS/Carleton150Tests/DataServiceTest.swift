//
//  DataServiceTest.swift
//  Carleton150
//
//  Created by Chet Aldrich on 11/3/15.
//  Copyright © 2015 edu.carleton.carleton150. All rights reserved.
//

import XCTest
@testable import Carleton150
import CoreLocation

class DataServiceTest: XCTestCase {
}
