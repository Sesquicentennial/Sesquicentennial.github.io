var database = require('./app/core/database'),
    router = require('./app/core/router');