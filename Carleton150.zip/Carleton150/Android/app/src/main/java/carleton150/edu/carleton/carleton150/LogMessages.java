package carleton150.edu.carleton.carleton150;

/**
 * Created by haleyhinze on 1/14/16.
 */
public class LogMessages {

    public String GEOFENCE_MONITORING = "GeofenceMonitoring";
    public String VOLLEY = "Volley";
    public String NETWORK = "Network";
    public String PERMISSIONS_INCORRECT = "IncorrectPermissions";
    public String LOCATION = "Location";
    public String MEMORY_MONITORING = "MemoryMonitoring";
    public String IMAGE_HANDLING = "ImageHandling";
}
