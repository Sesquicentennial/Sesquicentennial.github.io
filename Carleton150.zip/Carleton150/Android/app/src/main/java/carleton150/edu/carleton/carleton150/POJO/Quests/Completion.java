package carleton150.edu.carleton.carleton150.POJO.Quests;

/**
 * Created by haleyhinze on 2/11/16.
 */
public class Completion {

    private String text;
    private Image image;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public Image getImage() {
        return image;
    }

    public void setImage(Image image) {
        this.image = image;
    }
}
