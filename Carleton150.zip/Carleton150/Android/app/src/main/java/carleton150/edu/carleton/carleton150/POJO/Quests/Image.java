package carleton150.edu.carleton.carleton150.POJO.Quests;

/**
 * Created by haleyhinze on 2/11/16.
 */
public class Image {

    private String mimeType;
    private String image;

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
