package carleton150.edu.carleton.carleton150.Interfaces;

/**
 * Created by nayelymartinez on 2/18/16.
 */
public interface RecyclerViewDatesClickListener {

    public void recyclerViewListClicked(String dateInfo);
}
